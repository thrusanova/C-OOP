﻿namespace Mordor_sCrueltyPlan.Moods
{
  public class Sad:Mood
    {
        private const string MOOD = "Sad";
        public Sad() : base(MOOD)
        {
        }
    }
}
