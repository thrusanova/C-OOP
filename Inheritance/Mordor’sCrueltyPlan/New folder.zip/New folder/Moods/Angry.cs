﻿
namespace Mordor_sCrueltyPlan.Moods
{
   public class Angry:Mood
    {
        private const string MOOD="Angry";
        public Angry() : base(MOOD)
        {
        }
    }
}
