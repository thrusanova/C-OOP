﻿namespace Mordor_sCrueltyPlan.Moods
{
   public class Happy:Mood
    {

        private const string MOOD = "Happy";
        public Happy() : base(MOOD)
        {
        }
    }
}
