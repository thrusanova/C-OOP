﻿namespace Mordor_sCrueltyPlan.Moods
{
  public class Javascript:Mood
    {
        private const string MOOD = "Javascript";
        public Javascript() : base(MOOD)
        {

        }
    }
}
