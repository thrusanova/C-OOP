﻿

namespace MordorsCrueltyPlan.Foods
{
   public class Apple:Food
    {
        private const int POINTS = 1;
        public Apple() : base(POINTS)
        {
        }
    }
}
