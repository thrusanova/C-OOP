﻿using MordorsCrueltyPlan.Foods;

namespace MordorsCrueltyPlan
{
    public class Junk : Food
    {
        private const int POINTS = -1;
        public Junk():base(POINTS)
        {
        }
    }
}