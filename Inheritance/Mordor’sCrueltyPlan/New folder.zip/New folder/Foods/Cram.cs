﻿
namespace MordorsCrueltyPlan.Foods
{
   public class Cram:Food
    {
        private const int POINTS = 2;

        public Cram() : base(POINTS)
        {

        }
    }
}
