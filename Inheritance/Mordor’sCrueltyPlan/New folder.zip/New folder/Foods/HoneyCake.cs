﻿using MordorsCrueltyPlan.Foods;

namespace MordorsCrueltyPlan
{
    public class HoneyCake : Food
    {
        private const int POINTS = 5;
        public HoneyCake():base(POINTS)
        {
        }
    }
}