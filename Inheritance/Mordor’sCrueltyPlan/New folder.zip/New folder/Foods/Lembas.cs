﻿using MordorsCrueltyPlan.Foods;

namespace MordorsCrueltyPlan
{
    public class Lembas : Food
    {
        private const int POINTS = 3;
        public Lembas():base(POINTS)
        {
        }
    
    }
}