﻿
namespace MordorsCrueltyPlan.Foods
{
    public class Melon:Food
    {
        private const int POINTS = 1;
        public Melon() : base(POINTS)
        {
        }
    }
}
